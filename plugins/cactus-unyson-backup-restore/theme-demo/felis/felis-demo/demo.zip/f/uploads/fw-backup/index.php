<?php
header('HTTP/1.0 403 Forbidden');
die('<h1>Forbidden</h1>');