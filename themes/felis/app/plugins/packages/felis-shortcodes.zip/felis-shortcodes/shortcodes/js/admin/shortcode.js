// JavaScript Document
jQuery(document).ready(function(e) {
	jQuery(".cactus_tooltip").tooltip();
});